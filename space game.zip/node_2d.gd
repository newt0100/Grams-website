extends Node2D
@onready var character_body_2d = $CharacterBody2D
@onready var sprite = $CharacterBody2D/AnimatedSprite2D
var lives = 100
@onready var character_body_2d_2 = $CharacterBody2D2
var timer = 0.0
var spawn_timer = 2.0  # Initial spawn time
var difficulty_multiplier = 0.02  # How much the spawn timer decreases
var max_spawn_rate = 0.5  # Minimum spawn time
@onready var label = $Label
@onready var cam = $CharacterBody2D/Camera2D
var elapsed_time = 0.0  # Total time elapsed
@onready var sprite_2d_2 = $Sprite2D2
@onready var bullet = $CharacterBody2D/StaticBody2D/CollisionShape2D
@onready var label_2 = $Label2
# Add this variable for the hit effect
var is_hurt = false
var hurt_color = Color(1, 0, 0, 1)  # Red color for hurt effect
var normal_color = Color(1, 1, 1, 1)  # Normal color
var hurt_duration = 0.2  # Duration of the hurt effect
var score_base = 0
func _ready():
	if character_body_2d_2:
		create_character_body()

func _process(delta):

	label.position.y = character_body_2d.position.y - 300
	label.position.x = character_body_2d.position.x - 500
	label.text = "Health: " + str(lives) + " Score: " + str(score_base * 100)
	timer += delta
	elapsed_time += delta

	# Adjust spawn timer based on elapsed time
	if spawn_timer > max_spawn_rate:
		spawn_timer -= difficulty_multiplier * delta
		spawn_timer = max(spawn_timer, max_spawn_rate)

	if timer >= spawn_timer:
		timer = 0.0
		create_character_body()
		print("New character spawned!")

	# Handle hurt effect
	if is_hurt:
		sprite.modulate = hurt_color
		hurt_duration -= delta
		if hurt_duration <= 0:
			is_hurt = false
			sprite.modulate = normal_color
			hurt_duration = 0.2


func create_character_body():
	if character_body_2d_2:
		var new_character = character_body_2d_2.duplicate()
		add_child(new_character)
		new_character.position = Vector2(randf() * get_viewport().size.x, randf() * get_viewport().size.y)
	else:
		print("Error: character_body_2d_2 is not valid!")

func _on_area_2d_body_entered(body):
	if body == character_body_2d:
		sprite.play("hit")
		lives -= 15
		print("Lives left: ", lives)
		
		# Trigger hurt effect
		is_hurt = true
		sprite.modulate = hurt_color  # Change sprite color
		# Play hit sound (ensure you have a sound effect ready)

		if lives <= 0:
			go_to_dead_scene()
	else:
		score_base += 1
func go_to_dead_scene():
	get_tree().change_scene_to_file("res://dead.tscn")


func _on_area_2d_body_shape_entered(body_rid, body, body_shape_index, local_shape_index):
	pass # Replace with function body.
