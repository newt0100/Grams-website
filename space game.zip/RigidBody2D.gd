extends RigidBody2D

var speed = 3000  # Speed in pixels/sec
func _process(delta):

	linear_velocity = transform.x * speed * delta  # Move the bullet forward
