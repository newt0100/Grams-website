extends CharacterBody2D
@onready var og_bullet = $StaticBody2D
@onready var collision_shape_2d = $CollisionShape2D
@onready var label = $Camera2D/Label

var bullet_speed = 300  # Increased bullet speed
var speed = 1500  # Move speed in pixels/sec
var rotation_speed = 5.5  # Turning speed in radians/sec
var shift_speed_multiplier = 1.7  # Speed multiplier during shift
var shift_duration = 0.5  # Duration of the shift
var shift_cooldown = 1.0  # Cooldown time after shifting
var is_shifting = false
var shift_timer = 0.0

func _physics_process(delta):
	# Update shift timer
	if is_shifting:
		shift_timer -= delta
		if shift_timer <= 0:
			is_shifting = false

	# Get movement input
	var rotation_direction = Input.get_axis("left", "right")

	# Update rotation
	rotation += rotation_direction * rotation_speed * delta

	# Calculate velocity based on current rotation
	if is_shifting:
		velocity = transform.x * speed * shift_speed_multiplier
	else:
		velocity = transform.x * speed

	# Move the character
	move_and_slide()

	# Handle shift ability
	if Input.is_action_just_pressed("shift") and not is_shifting and shift_timer <= 0:
		is_shifting = true
		shift_timer = shift_duration

	# Handle shooting
	if Input.is_action_just_pressed("shoot"):
		
		# Create multiple bullets
		for i in range(-1, 2):  # Creates 3 bullets in a spread (left, center, right)
			var bullet = og_bullet.duplicate()
			bullet.position = position
			bullet.rotation = rotation + deg_to_rad(10 * i)  # Adjust angle for spread
			get_tree().root.add_child(bullet)
		


