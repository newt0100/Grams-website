extends StaticBody2D
@onready var character_body_2d = $".."

var speed = 3000  # Speed in pixels/sec

func _process(delta):
	# Get the direction based on the current rotation
	var direction = Vector2(cos(rotation), sin(rotation  ))
	position += direction.normalized() * speed * delta  # Move the bullet forward
