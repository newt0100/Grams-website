extends CharacterBody2D

@onready var character_body_2d = $"../CharacterBody2D"
@onready var nav = $NavigationAgent2D
var health = 3
const SPEED = 200.0
const exel = 7
@onready var label_2 = $"../Label2"
var score = 0
var garfeild = false
func _add_a_scene_manually():
	# This is like autoloading the scene, only
	# it happens after already loading the main scene.
	get_tree().change_scene_to_file("res://dead.tscn")
func _physics_process(delta):
	var direction = Vector2()
	nav.target_position = character_body_2d.position
	direction = nav.get_next_path_position() - global_position
	direction = direction.normalized()
	# Update the velocity
	velocity = velocity.lerp(direction * SPEED, exel * delta)
	# Rotate to face the direction of movement
	if velocity.length() > 0:
		rotation = velocity.angle()
	if health == 0:
		_add_a_scene_manually()
	move_and_slide()

func _on_area_2d_body_entered(body):
	if body == character_body_2d:
		health - 1
	
	if body is StaticBody2D:  # Check if the body is a StaticBody2D
		body.queue_free()  # Remove the StaticBody2D
		queue_free()
		




