extends Node2D
@onready var label = $Label

# Called when the node enters the scene tree for the first time.



# Called every frame. '


func _on_button_pressed():
	get_tree().change_scene_to_file("res://node_2d.tscn")
